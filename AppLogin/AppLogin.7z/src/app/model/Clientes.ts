export class Clientes {
    idCliente: String;
    nombreContacto: String;
    cargoContacto: String;
    ciudad: String;
    region: String;
    telefono: String;
    Clave:string;

    constructor() {
        this.idCliente = this.idCliente;
        this.nombreContacto = this.nombreContacto;
        this.cargoContacto = this.cargoContacto;
        this.ciudad = this.ciudad;
        this.region = this.region;
        this.telefono = this.telefono;
        this.Clave  = this.Clave;
    }
}