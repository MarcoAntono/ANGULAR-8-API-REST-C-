import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emcabezado',
  templateUrl: './emcabezado.component.html',
  styleUrls: ['./emcabezado.component.scss']
})
export class EmcabezadoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
